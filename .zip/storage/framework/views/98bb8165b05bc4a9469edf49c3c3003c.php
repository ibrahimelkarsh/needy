<!DOCTYPE html>
<html lang="en">

<!-- begin::Head -->
<head>
    <meta charset="utf-8" />
    <title>المحتاجين | لوحة التحكم</title>
    <meta name="description" content="Latest updates and statistic charts">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">

    <!--begin::Web font -->
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
    <script>
        WebFont.load({
            google: {"families":["Changa:300,400,500,600,800","Roboto:300,400,500,600,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!--end::Web font -->

    <!--begin::Global Theme Styles -->
    <!--<link href="assets/vendors/base/vendors.bundle.css" rel="stylesheet" type="text/css" />-->

    <link href="<?php echo e(asset('cpanel/vendors/base/vendors.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css" />
    <!--<link href="assets/demo/default/base/style.bundle.css" rel="stylesheet" type="text/css" />-->

    <link href="<?php echo e(asset('cpanel/demo/default/base/style.bundle.rtl.css')); ?>" rel="stylesheet" type="text/css" />

    <!--end::Global Theme Styles -->
    <link rel="shortcut icon" href="<?php echo e(asset('cpanel/app/media/img/logos/icon.ico')); ?>" />
    <style>
        .m-login--2::before
        {
            background-color: rgba(255, 255, 255, 0.9) !important;
        }

        .m-login.m-login--2.m-login-2--skin-1 .m-login__container .m-login__head .m-login__title {
            color: #000;
        }

        .m-login.m-login--2.m-login-2--skin-1 .m-login__container .m-login__form .m-login__form-action .m-login__btn.m-login__btn--primary
        {
            color: #0bb393;
            border-color: #087f68;
            background-color: transparent;
        }

        .m-login.m-login--2.m-login-2--skin-1 .m-login__container .m-login__form .m-login__form-action .m-login__btn.m-login__btn--primary:hover
        {
            color: #0bb393 !important;
            border-color: #087f68 !important;
            background-color: transparent !important;
        }

        .m-login.m-login--2 .m-login__wrapper .m-login__container .m-login__form .m-form__group .form-control ,
        .m-login.m-login--2 .m-login__wrapper .m-login__container .m-login__form .m-form__group .form-control.m-login__form-input--last{
            border-radius: 10px;
            border: 1px solid #d9222e3b;
            margin-top: 1.5rem;
        }

        .m-login.m-login--2.m-login-2--skin-1 .m-login__container .m-login__form .form-control
        {
            /*color: #000!important;*/
            /*background: #d9222e3b !important;*/
        }

        ::-webkit-input-placeholder { /* WebKit, Blink, Edge */
            color:    #fff !important;
        }


    </style>
</head>

<!-- end::Head -->

<!-- begin::Body -->
<body class="m--skin- m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--fixed m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default">

<!-- begin:: Page -->
<div class="m-grid m-grid--hor m-grid--root m-page">
    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--hor m-login m-login--signin m-login--2 m-login-2--skin-1" id="m_login">
        <div class="m-grid__item m-grid__item--fluid m-login__wrapper">
            <div class="m-login__container">
                <br><br><br><br><br>
                <div class="m-login__signin">
                    <div class="m-login__head">
                        <h3 class="m-login__title">لوحة التحكم</h3>
                        <h3 class="m-login__title">تسجيل الدخول الى لوحة التحكم</h3>
                    </div>

                    <?php echo $__env->make('includes.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form class="m-login__form m-form" action="<?php echo e(route('login')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group m-form__group">
                            <input class="form-control m-input" type="email" placeholder="البريد الالكتروني" name="email" autocomplete="off">
                        </div>
                        <div class="form-group m-form__group">
                            <input class="form-control m-input m-login__form-input--last" type="password" placeholder="كلمة المرور" name="password">
                        </div>

                        <div class="m-login__form-action">
                            <button type="submit"  class="btn btn-success m-btn m-btn--pill m-btn--custom m-btn--air  m-login__btn m-login__btn--primary">تسجيل الدخول</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- end:: Page -->

<!--begin::Global Theme Bundle -->
<script src="<?php echo e(asset('cpanel/vendors/base/vendors.bundle.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('cpanel/demo/default/base/scripts.bundle.js')); ?>" type="text/javascript"></script>

<!--end::Global Theme Bundle -->

<!--begin::Page Scripts -->
<script src="<?php echo e(asset('cpanel/snippets/custom/pages/user/login.js')); ?>" type="text/javascript"></script>


<!--end::Page Scripts -->
</body>

<!-- end::Body -->
</html>
<?php /**PATH C:\laragon\www\needy\resources\views/auth/login.blade.php ENDPATH**/ ?>