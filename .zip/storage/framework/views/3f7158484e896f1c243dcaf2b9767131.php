
<?php if(count($errors) > 0): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger" role="alert">
               <strong></strong> <?php echo e($error); ?>

    </div>

   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php if(session('error')): ?>
    <div role="alert" class="alert alert-danger" role="alert" style="text-align: right">
       	<strong></strong> <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div role="alert" class="alert alert-success" role="alert" style="text-align: right;">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\needy\resources\views/includes/errors.blade.php ENDPATH**/ ?>