<?php $__env->startSection('content'); ?>

    <style>
        .card .card-header ,.card .card-body {
            text-align: center;
        }
    </style>

    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">

    <?php echo $__env->make('includes.menu-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <br>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد الحالات</div>

                        <div class="card-body">
                            <?php echo e($needy_count); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد البرعات</div>

                        <div class="card-body">
                            <?php echo e($donation_count); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد التبرعات النقدية</div>

                        <div class="card-body">
                            <?php echo e($donation_cash_count); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد التبرعات العينية</div>

                        <div class="card-body">
                            <?php echo e($donation_eye_count); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\needy\resources\views/admin/home.blade.php ENDPATH**/ ?>