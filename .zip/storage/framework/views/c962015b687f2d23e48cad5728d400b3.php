<?php $__env->startSection('content'); ?>

    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">

        <?php echo $__env->make('includes.menu-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-grid__item m-grid__item--fluid m-wrapper">

            <!-- BEGIN: Subheader -->
            <div class="m-subheader ">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h3 class="m-subheader__title ">
                            المحتاجين
                        </h3>
                    </div>
                </div>
            </div>

            <!-- END: Content -->
            <div class="m-content">
                <div class="row">
                    <div class="col-12">
                        <div class="m-portlet m-portlet--full-height ">
                            <div class="m-portlet__head">
                                <div class="m-portlet__head-caption">
                                    <div class="m-portlet__head-title">
                                        <h3 class="m-portlet__head-text">
                                            المحتاجين
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="m-portlet__body">
                                <div class="order-xl-2 m--align-left">
                                    <a href="<?php echo e(route('admin.needies.create')); ?>" class="btn btn-info m-btn m-btn--custom m-btn--icon m-btn--air m-btn--pill">
                                        <span><i class="la la-plus-circle"></i>
                                            <span>اضافة</span>
                                        </span>
                                    </a>
                                    <div class="m-separator m-separator--dashed d-xl-none"></div>
                                </div>

                                <table class="table table-striped- table-bordered table-hover table-checkable"
                                       id="m_table_1">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>رقم الموبايل</th>
                                        <th>الخدمات</th>
                                        <th>تعديل</th>
                                        <th>حذف</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($list->count() > 0): ?>
                                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($key + 1); ?></td>
                                                    <td><?php echo e($item->name); ?></td>
                                                    <td><?php echo e($item->mobile_no); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(route('admin.donations.index',$item->id)); ?>" class="btn btn-primary m-btn m-btn--icon m-btn--icon-only" >
                                                            <i class="fa fa-map"></i>
                                                        </a>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('admin.needies.edit',$item->id)); ?>" class="btn btn-primary m-btn m-btn--icon m-btn--icon-only" >
                                                            <i class="fa fa-pencil-alt"></i>
                                                        </a>
                                                    </td>
                                                    <td><a href="#" data-toggle="modal" data-target="#deleteModal<?php echo e($item->id); ?>" class="btn btn-danger m-btn m-btn--icon m-btn--icon-only">
                                                            <i class="fa fa-trash-alt"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <div id="deleteModal<?php echo e($item->id); ?>" class="modal fade" role="dialog">
                                                    <div class="modal-dialog">
                                                        <!-- Modal content-->
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h4 class="modal-title">تنبيه الحذف!</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>هل انت متأكد انك تريد الحذف</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <form action="<?php echo e(route('admin.needies.destroy',$item->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo e(method_field('DELETE')); ?>

                                                                    <button type="submit" class="btn btn-danger">حذف</button>
                                                                    <button type="button" class="btn btn-default" data-dismiss="modal">إلغاء</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>

        <script src="<?php echo e(asset('cpanel/vendors/custom/datatables/datatables.bundle.js')); ?>" type="text/javascript"></script>
        <script>
            var DatatablesBasicHeaders = function () {
                var initTable1 = function () {
                    var table = $('#m_table_1');
                    // begin first table
                    table.DataTable({
                        responsive: true,
                        pageLength: 10,
                        paging: true,
                        searching: true,
                    });
                };
                return {
                    //main function to initiate the module
                    init: function () {
                        initTable1();
                    },
                };
            }();

            jQuery(document).ready(function () {
                DatatablesBasicHeaders.init();
            });
        </script>

    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\needy\resources\views/admin/needies/index.blade.php ENDPATH**/ ?>