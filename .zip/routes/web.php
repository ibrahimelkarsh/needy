<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

Route::get('clear', [App\Http\Controllers\HomeController::class,'clear'])->name('clear');

Auth::routes();

Route::get('/', [App\Http\Controllers\HomeController::class,'index'])->name('admin');


Route::group(['middleware' => ['auth']], function () {
    Route::get('profile', [App\Http\Controllers\Admin\UserController::class,'show'])->name('profile');
    Route::patch('profile', [App\Http\Controllers\Admin\UserController::class,'update'])->name('profile.update');

    Route::group(['prefix' => 'users'], function () {
        Route::get('/', [App\Http\Controllers\Admin\UserController::class,'index'])->name('admin.users.index');
        Route::get('create', [App\Http\Controllers\Admin\UserController::class,'create'])->name('admin.users.create');
        Route::post('/', [App\Http\Controllers\Admin\UserController::class,'store'])->name('admin.users.store');
        Route::get('{id}/edit', [App\Http\Controllers\Admin\UserController::class,'edit'])->name('admin.users.edit');
        Route::put('{id}/update', [App\Http\Controllers\Admin\UserController::class,'update'])->name('admin.users.update');
        Route::delete('destroy/{id}', [App\Http\Controllers\Admin\UserController::class,'destroy'])->name('admin.users.destroy');
    });
    Route::group(['prefix' => 'donors'], function () {
        Route::get('/', [App\Http\Controllers\Admin\DonorController::class,'index'])->name('admin.donors.index');
        Route::get('create', [App\Http\Controllers\Admin\DonorController::class,'create'])->name('admin.donors.create');
        Route::post('/', [App\Http\Controllers\Admin\DonorController::class,'store'])->name('admin.donors.store');
        Route::get('{id}/edit', [App\Http\Controllers\Admin\DonorController::class,'edit'])->name('admin.donors.edit');
        Route::put('{id}/update', [App\Http\Controllers\Admin\DonorController::class,'update'])->name('admin.donors.update');
        Route::delete('destroy/{id}', [App\Http\Controllers\Admin\DonorController::class,'destroy'])->name('admin.donors.destroy');
    });
    Route::group(['prefix' => 'needies'], function () {
        Route::get('/', [App\Http\Controllers\Admin\NeedyController::class,'index'])->name('admin.needies.index');
        Route::get('create', [App\Http\Controllers\Admin\NeedyController::class,'create'])->name('admin.needies.create');
        Route::post('/', [App\Http\Controllers\Admin\NeedyController::class,'store'])->name('admin.needies.store');
        Route::get('{id}/edit', [App\Http\Controllers\Admin\NeedyController::class,'edit'])->name('admin.needies.edit');
        Route::put('{id}/update', [App\Http\Controllers\Admin\NeedyController::class,'update'])->name('admin.needies.update');
        Route::delete('destroy/{id}', [App\Http\Controllers\Admin\NeedyController::class,'destroy'])->name('admin.needies.destroy');
    });
    Route::group(['prefix' => 'donations'], function () {
        Route::get('{needy_id}', [App\Http\Controllers\Admin\DonationController::class,'index'])->name('admin.donations.index');
        Route::post('{needy_id}', [App\Http\Controllers\Admin\DonationController::class,'store'])->name('admin.donations.store');
        Route::get('{id}/edit', [App\Http\Controllers\Admin\DonationController::class,'edit'])->name('admin.donations.edit');
        Route::put('{id}/update', [App\Http\Controllers\Admin\DonationController::class,'update'])->name('admin.donations.update');
        Route::delete('destroy/{id}', [App\Http\Controllers\Admin\DonationController::class,'destroy'])->name('admin.donations.destroy');
    });
    Route::group(['prefix' => 'transactions'], function () {
        Route::get('{donor_id}', [App\Http\Controllers\Admin\TransactionController::class,'index'])->name('admin.transactions.index');
        Route::post('{donor_id}', [App\Http\Controllers\Admin\TransactionController::class,'store'])->name('admin.transactions.store');
        Route::get('{id}/edit', [App\Http\Controllers\Admin\TransactionController::class,'edit'])->name('admin.transactions.edit');
        Route::put('{id}/update', [App\Http\Controllers\Admin\TransactionController::class,'update'])->name('admin.transactions.update');
        Route::delete('destroy/{id}', [App\Http\Controllers\Admin\TransactionController::class,'destroy'])->name('admin.transactions.destroy');
    });

});
