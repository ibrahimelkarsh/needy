<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Foundation\Http\FormRequest;

class NeedyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => ['required'],
            'children_no' => ['min:0'],
        ];
    }


    public function messages()
    {
        return [
            'name.required' => 'الاسم مطلوب',
            'children_no.min' => 'عدد الاطفال اكبر من -1',
        ];
    }

    public function attributes()
    {
        return [
            'name' => 'الاسم',
        ];
    }
}
