<?php

namespace App\Http\Controllers;

use App\Models\Donation;
use App\Models\Needy;
use Illuminate\Support\Facades\Artisan;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $active = "admin";
        $needy_count = Needy::count();
        $donation_count = Donation::count();
        $donation_cash_count = Donation::where('type','نقدي')->count();
        $donation_eye_count = Donation::where('type','عيني')->count();

        return view('admin.home')
            ->with(compact('active','needy_count','donation_count','donation_cash_count','donation_eye_count'));
    }

    public function clear(){
        Artisan::call('cache:clear');
        Artisan::call('config:clear');
        Artisan::call('view:clear');

        return "All is cleared";
    }
}
