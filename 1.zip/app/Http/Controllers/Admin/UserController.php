<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class UserController extends Controller
{
    public function index()
    {
        $active = "users";
        $list = User::where('is_donor',0)->orderBy('created_at','desc')->get();
        return view('admin.users.index', compact('active','list'));
    }
    public function create()
    {
        $active = "users";
        return view('admin.users.create')->with(compact('active'));
    }

    public function store(UserRequest $request)
    {
        $request['is_donor']=0;
        $object = User::create($request->all());
        if ($object)
            return redirect()->route('admin.users.index')->with('success', 'تم اضافة المعلومات بنجاح');
        return redirect()->route('admin.users.create')->with('error', 'الرجاء ملئ المعلومات بشكل صحيح');
    }
    public function edit($id)
    {
        $user = User::findOrFail($id);
        $active = "users";
        return view('admin.users.edit', compact('active','user'));
    }

    /**
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update($id)
    {
        $user = User::findOrFail($id);
        if(strtolower(Auth::user()->email) == strtolower(request('email'))) {

            if(is_null(request('password'))){

                $this->validate(request(), [
                    'name' => 'required',
                ]);
                $user->name = request('name');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            } else {
                $this->validate(request(), [
                    'name' => 'required',
                    'password' => 'required|min:6|confirmed'
                ]);
                $user->name = request('name');
                $user->password = request('password');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            }
        }
        else{

            if(is_null(request('password'))){

                $this->validate(request(), [
                    'name' => 'required',
                    'email' => 'email|required|unique:users,email,' . $user->id,
                ]);
                $user->name = request('name');
                $user->email = request('email');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            } else {

                $this->validate(request(), [
                    'name' => 'required',
                    //'email' => 'required|email|unique:users',
                    'email' => 'email|required|unique:users,email,' . $user->id,
                    'password' => 'required|min:6|confirmed'
                ]);
                $user->name = request('name');
                $user->email = request('email');
                $user->password = request('password');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            }
        }
    }

    public function destroy($id)
    {
        User::findOrFail($id)->delete();
        return back()->with('success', 'تم حذف المعلومات بنجاح');
    }
}
