<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Http\Controllers\Controller;

class ProfileController extends Controller
{
    public function show()
    {
        $active = "user";
        $user = auth()->user();
        return view('admin.profile.edit', compact('active','user'));
    }
    public function update(Request $request)
    {
        $user = User::findOrFail(auth()->user()->id);
        if(strtolower(Auth::user()->email) == strtolower(request('email'))) {

            if(is_null(request('password'))){

                $this->validate(request(), [
                    'name' => 'required',
                ]);
                $user->name = request('name');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            } else {
                $this->validate(request(), [
                    'name' => 'required',
                    'password' => 'required|min:6|confirmed'
                ]);
                $user->name = request('name');
                $user->password = request('password');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            }
        }
        else{

            if(is_null(request('password'))){

                $this->validate(request(), [
                    'name' => 'required',
                    'email' => 'email|required|unique:users,email,' . $user->id,
                ]);
                $user->name = request('name');
                $user->email = request('email');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            } else {

                $this->validate(request(), [
                    'name' => 'required',
                    //'email' => 'required|email|unique:users',
                    'email' => 'email|required|unique:users,email,' . $user->id,
                    'password' => 'required|min:6|confirmed'
                ]);
                $user->name = request('name');
                $user->email = request('email');
                $user->password = request('password');
                $user->save();
                return back()->with('success', 'تم تعديل المعلومات بنجاح');
            }
        }
    }
}
