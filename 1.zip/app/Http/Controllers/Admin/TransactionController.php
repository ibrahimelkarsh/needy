<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\WalletRequest;
use App\Models\Donation;
use App\Models\DonorWalletTransaction;
use App\Models\Needy;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class TransactionController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index($donor_id)
    {
        $active ="donor";
        $donor = User::findOrFail($donor_id);
        $list= $donor->transactions;
        return view('admin.transactions.index')->with(compact('active','list','donor'));
    }

    public function store(WalletRequest $request, $donor_id)
    {
        try {
            $donor = User::findOrFail($donor_id);
            $amount = $request->get('amount');

            $balance = $donor->balance;
            $balance += $amount;
            $donor->balance = $balance;
            $donor->save();
            $transactionData = [
                'donor_id' => $donor_id,
                'amount' => $amount,
                'type_id' => 1,
            ];
            DonorWalletTransaction::create($transactionData);

            return redirect()->route('admin.transactions.index', $donor_id)->with('success', 'تمت إضافة الرصيد بنجاح');
        } catch (ModelNotFoundException $modelNotFoundException) {
            return redirect()->route('admin.transactions.index', $donor_id)->with('error', 'حدث خطأ في إضافة الرصيد');
        }
    }


    public function edit($id)
    {
        $active = "donations";
        $data = Donation::findOrFail($id);
        $donors = User::where('is_donor',1)->get();
        return view('admin.donations.edit')->with(compact('active','data','donors'));
    }

    public function update(WalletRequest $request, $id)
    {
        try {
            $object = Donation::findOrFail($id);
            $old_donor = $object->donor;
            $old_amount = $object->value;
            $old_type = $object->type;

            $new_donor_id = $request->get('donor_id');
            $new_donor = User::findOrFail($new_donor_id);
            $new_type = $request->get('type');
            $new_amount = $request->get('value');

            // إذا غير الممول وكان نوع التبرع السابق نقدي
            // او إذا الممول ما تغير بس نوع التبرع تغير من نقدي إلي عيني رجع لفلوس بالحالتين
            if(($new_donor_id != $old_donor->id && $old_type == 'نقدي') ||
            ($new_donor_id == $old_donor->id && $old_type == 'نقدي' && $new_type == 'عيني')){
                $trans_where_arr = [
                    'donor_id' => $old_donor->id,
                    'donation_id' => $id,
                ];
                DonorWalletTransaction::where($trans_where_arr)->delete();
                $balance = $old_donor->balance;
                $balance += $old_amount;
                $old_donor->balance = $balance;
                $old_donor->save();
            } else if ($new_donor_id == $old_donor->id && $old_type == $new_type && $new_type == 'نقدي' && $old_amount != $new_amount ){
                $trans_where_arr = [
                    'donor_id' => $new_donor_id,
                    'donation_id' => $id,
                ];
                $trans = DonorWalletTransaction::where($trans_where_arr)->first();
                $trans->amount = $new_amount;
                $trans->save();

                $balance = $old_donor->balance;
                $balance -= ($new_amount - $old_amount);
                $old_donor->balance = $balance;
                $old_donor->save();
            }
            if(($new_donor_id != $old_donor->id && $new_type == 'نقدي') ||
            ($new_donor_id == $old_donor->id && $old_type == 'عيني' && $new_type == 'نقدي')){
                $trans_data = [
                    'donor_id' => $new_donor_id,
                    'amount' => $new_amount,
                    'type_id' => 2,
                    'needy_id' => $object->needy_id,
                    'donation_id' => $object->id
                ];
                DonorWalletTransaction::create($trans_data);
                $balance = $new_donor->balance;
                $balance -= $new_amount;
                $new_donor->balance = $balance;
                $new_donor->save();
            }

            $object->update($request->all());
            return redirect()->route('admin.donations.index',$object->needy_id)->with('success', 'تم تعديل المعلومات بنجاح');
        } catch (ModelNotFoundException $modelNotFoundException) {
            return redirect()->route('admin.donations.edit',$id)->with('error', 'الرجاء إدخال المعلومات بشكل صحيح');
        }
    }

    public function destroy($id)
{
    try {
        $transaction = DonorWalletTransaction::findOrFail($id);
        $donor = User::findOrFail($transaction->donor_id);

        $balance = $donor->balance;
        $balance -= $transaction->amount;
        $donor->balance = $balance;
        $donor->save();

        $transaction->delete();

        return redirect()->route('admin.transactions.index', $donor->id)->with('success', 'تم حذف المبلغ بنجاح');
    } catch (ModelNotFoundException $modelNotFoundException) {
        return redirect()->route('admin.transactions.index', $donor->id)->with('error', 'حدث خطأ في حذف المبلغ');
    }
}

}
