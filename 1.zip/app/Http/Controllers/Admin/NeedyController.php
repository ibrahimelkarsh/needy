<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\NeedyRequest;
use App\Models\Needy;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class NeedyController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $active = "needies";
        $list = Needy::orderBy('created_at','desc')->get();
        return view('admin.needies.index')->with(compact('active','list'));
    }
    public function create()
    {
        $active = "needies";
        return view('admin.needies.create')->with(compact('active'));
    }

    public function store(NeedyRequest $request)
    {
        $object = Needy::create($request->all());
        if ($object)
            return redirect()->route('admin.needies.index')->with('success', 'تم اضافة المعلومات بنجاح');
        return redirect()->route('admin.needies.create')->with('error', 'الرجاء ملئ المعلومات بشكل صحيح');
    }

    public function edit($id)
    {
        $active = "needies";
        $data = Needy::findOrFail($id);
        return view('admin.needies.edit')->with(compact('active','data'));
    }

    public function update(NeedyRequest $request, $id)
    {
        try {
            $object = Needy::findOrFail($id);
            $object->update($request->all());
            return redirect()->route('admin.needies.index')->with('success', 'تم تعديل المعلومات بنجاح');
        } catch (ModelNotFoundException $modelNotFoundException) {
            return redirect()->route('admin.needies.edit',$id)->with('error', 'الرجاء إدخال المعلومات بشكل صحيح');
        }
    }

    public function destroy($id)
    {
        Needy::findOrFail($id)->delete();
        return back()->with('success', 'تم حذف المعلومات بنجاح');
    }
}
