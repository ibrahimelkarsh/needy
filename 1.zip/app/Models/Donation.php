<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Donation extends Model
{
    use SoftDeletes;

    public $table = 'donations';
    protected $fillable = ['needy_id','donor_id','type','value'];
    protected $primaryKey = 'id';

    public function needy(){
        return $this->hasOne(Needy::class,'id','needy_id');
    }
    public function donor(){
        return $this->hasOne(User::class,'id','donor_id');
    }
}
