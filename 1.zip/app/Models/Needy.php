<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Needy extends Model
{
    use SoftDeletes;

    public $table = 'needies';
    protected $fillable = ['name','dob','job','marital_status','children_no','house_type','address','mobile_no','need'];
    protected $primaryKey = 'id';

    public function donations(){
        return $this->hasMany(Donation::class,'needy_id')->orderBy('created_at','desc');
    }

}
