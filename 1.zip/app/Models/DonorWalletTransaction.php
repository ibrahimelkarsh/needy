<?php

namespace App\Models;

use App\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DonorWalletTransaction extends Model
{
    use SoftDeletes;

    public $table = 'donor_wallet_transactions';
    protected $fillable = ['donor_id','amount','type_id','needy_id','donation_id'];
    protected $primaryKey = 'id';

    public function donor(){
        return $this->hasOne(User::class,'id','donor_id');
    }
    public function type(){
        return $this->hasOne(TransactionType::class,'id','type_id');
    }
    public function needy(){
        return $this->hasOne(Needy::class,'id','needy_id');
    }
    public function donation(){
        return $this->hasOne(Donation::class,'id','donation_id');
    }
}
