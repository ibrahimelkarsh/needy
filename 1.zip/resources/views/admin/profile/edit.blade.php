@extends('layouts.app')

@section('content')

    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
        @include('includes.menu-admin')
        <div class="m-grid__item m-grid__item--fluid m-wrapper">
            <!-- BEGIN: Subheader -->
            <div class="m-subheader ">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h3 class="m-subheader__title ">الملف الشخصي</h3>
                    </div>

                </div>
            </div>
            <!-- END: Content -->
            <div class="m-content">
                <div class="row">
                    <div class="col-md-12">
                        <!--begin::Portlet-->
                        <div class="m-portlet m-portlet--tab">
                            <div class="m-portlet__head">
                                <div class="m-portlet__head-caption">
                                    <div class="m-portlet__head-title">
												<span class="m-portlet__head-icon m--hide">
													<i class="la la-gear"></i>
												</span>
                                        <h3 class="m-portlet__head-text">
                                            الملف الشخصي
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <!--begin::Form-->
                            <form class="m-form m-form--fit m-form--label-align-right" method="POST"
                                  action="{{route('profile.update')}}" enctype="multipart/form-data">
                                @csrf
                                {{ method_field('PATCH') }}
                                <div class="m-portlet__body">
                                    @include('includes.errors')

                                    <div class="m-portlet__body" style="padding: 0;">
                                        <div class="form-group m-form__group">
                                            <label for="name_ar">الاسم</label>
                                            <input type="text" class="form-control m-input m-input--square" name="name"
                                                   value="{{ $user->name }}" required />
                                        </div>
                                        <div class="form-group m-form__group">
                                            <label for="email">البريد الالكتروني</label>
                                            <input type="email" class="form-control m-input m-input--square" name="email"
                                                   value="{{ $user->email }}" required />
                                        </div>
                                        <div class="form-group m-form__group">
                                            <label for="password">كلمة المرور</label>
                                            <input type="password" class="form-control m-input m-input--square" name="password" />
                                        </div>
                                        <div class="form-group m-form__group">
                                            <label for="password_confirmation">تأكيد كلمة المرور</label>
                                            <input type="password" class="form-control m-input m-input--square" name="password_confirmation" />
                                        </div>
                                    </div>
                                    <div class="m-portlet__foot m-portlet__foot--fit">
                                        <div class="m-form__actions">
                                            <button type="submit" class="btn btn-success">تعديل</button>
                                            <a href="{{ route('admin') }}"
                                               class="btn btn-secondary">إلغاء</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!--end::Form-->
                        </div>
                        <!--end::Portlet-->
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

