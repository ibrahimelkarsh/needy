@extends('layouts.app')
@section('content')

    <style>
        .card .card-header ,.card .card-body {
            text-align: center;
        }
    </style>

    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">

    @include('includes.menu-admin')
        <div class="container">
            <br>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد الحالات</div>

                        <div class="card-body">
                            {{$needy_count}}
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد البرعات</div>

                        <div class="card-body">
                            {{$donation_count}}
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد التبرعات النقدية</div>

                        <div class="card-body">
                            {{$donation_cash_count}}
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-header">عدد التبرعات العينية</div>

                        <div class="card-body">
                            {{$donation_eye_count}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
