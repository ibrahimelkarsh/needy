@extends('layouts.app')

@section('content')

    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">

        @include('includes.menu-admin')
        <div class="m-grid__item m-grid__item--fluid m-wrapper">

            <!-- BEGIN: Subheader -->
            <div class="m-subheader ">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h3 class="m-subheader__title ">
                            المتبرعين
                        </h3>
                    </div>
                </div>
            </div>

            <!-- END: Content -->
            <div class="m-content">
                <div class="row">
                    <div class="col-12">
                        <div class="m-portlet m-portlet--full-height ">
                            <div class="m-portlet__head">
                                <div class="m-portlet__head-caption">
                                    <div class="m-portlet__head-title">
                                        <h3 class="m-portlet__head-text">
                                            المتبرعين
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div class="m-portlet__body">
                                <div class="order-xl-2 m--align-left">
                                    <a href="{{ route('admin.donors.create') }}" class="btn btn-info m-btn m-btn--custom m-btn--icon m-btn--air m-btn--pill">
                                        <span><i class="la la-plus-circle"></i>
                                            <span>اضافة</span>
                                        </span>
                                    </a>
                                    <div class="m-separator m-separator--dashed d-xl-none"></div>
                                </div>

                                <table class="table table-striped- table-bordered table-hover table-checkable"
                                       id="m_table_1">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>البريد الالكتروني</th>
                                        <th>الرصيد</th>
                                        <th>اضافه رصيد</th>
                                        <th>تعديل</th>
                                        <th>حذف</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if($list->count() > 0)
                                        @foreach($list as $key => $item)
                                            <tr>
                                                <td>{{ $key + 1 }}</td>
                                                <td>{{ $item->name }}</td>
                                                <td>{{ $item->email }}</td>
                                                <td>{{ $item->balance }}</td>
                                                <td>
                                                    <a href="{{ route('admin.transactions.index',$item->id) }}" class="btn btn-primary m-btn m-btn--icon m-btn--icon-only">
                                                        <i class="fa fa-wallet"></i>
                                                    </a>
                                                </td>

                                                <td>
                                                    <a href="{{ route('admin.donors.edit',$item->id) }}" class="btn btn-primary m-btn m-btn--icon m-btn--icon-only">
                                                        <i class="fa fa-pencil-alt"></i>
                                                    </a>
                                                </td>
                                                <td><a href="#" data-toggle="modal" data-target="#deleteModal{{ $item->id }}" class="btn btn-danger m-btn m-btn--icon m-btn--icon-only">
                                                        <i class="fa fa-trash-alt"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                            <div id="deleteModal{{ $item->id }}" class="modal fade" role="dialog">
                                                <div class="modal-dialog">
                                                    <!-- Modal content-->
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">تنبيه الحذف!</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>هل أنت متأكد أنك تريد حذف؟</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form action="{{ route('admin.donors.destroy',$item->id) }}" method="POST">
                                                                @csrf
                                                                {{ method_field('DELETE') }}
                                                                <button type="submit" class="btn btn-danger">حذف</button>
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">الغاء</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('js')

        <script src="{{ asset('cpanel/vendors/custom/datatables/datatables.bundle.js') }}" type="text/javascript"></script>
        <script>
            var DatatablesBasicHeaders = function () {
                var initTable1 = function () {
                    var table = $('#m_table_1');
                    // begin first table
                    table.DataTable({
                        responsive: true,
                        pageLength: 10,
                        paging: true,
                        searching: true,
                    });
                };
                return {
                    //main function to initiate the module
                    init: function () {
                        initTable1();
                    },
                };
            }();

            jQuery(document).ready(function () {
                DatatablesBasicHeaders.init();
            });
        </script>

    @endpush
@endsection
