@extends('layouts.app')

@section('content')

    <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
        @include('includes.menu-admin')
        <div class="m-grid__item m-grid__item--fluid m-wrapper">
            <!-- BEGIN: Subheader -->
            <div class="m-subheader ">
                <div class="d-flex align-items-center">
                    <div class="mr-auto">
                        <h3 class="m-subheader__title ">التعديل</h3>
                    </div>

                </div>
            </div>
            <!-- END: Content -->
            <div class="m-content">
                <div class="row">
                    <div class="col-md-12">
                        <!--begin::Portlet-->
                        <div class="m-portlet m-portlet--tab">
                            <div class="m-portlet__head">
                                <div class="m-portlet__head-caption">
                                    <div class="m-portlet__head-title">
                                        <span class="m-portlet__head-icon m--hide">
                                            <i class="la la-gear"></i>
                                        </span>
                                        <h3 class="m-portlet__head-text">
                                            التعديل
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <!--begin::Form-->
                            <form class="m-form m-form--fit m-form--label-align-right" method="POST"
                                  action="{{route('admin.donations.update',$data->id)}}" enctype="multipart/form-data">
                                @csrf
                                @method('put')
                                <div class="m-portlet__body">
                                    @include('includes.errors')
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group m-form__group">
                                                <label for="donor_id">المتبرع</label>
                                                <select name="donor_id" id="donor_id" class="form-control" style="height: 40px !important;">
                                                    @foreach ($donors as $donor)
                                                        <option value="{{$donor->id}}" {{$data->donor_id==$donor->id?'selected':''}}>{{$donor->name}}</option>
                                                    @endforeach

                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group m-form__group">
                                                <label for="type">نوع التبرع</label>
                                                <select name="type" id="type" class="form-control" style="height: 40px !important;">
                                                    <option value="نقدي" {{$data->type=='نقدي'?'selected':''}}>نقدي</option>
                                                    <option value="عيني" {{$data->type=='عيني'?'selected':''}}>عيني</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group m-form__group">
                                                <label for="value">قيمة التبرع</label>
                                                <input type="number" class="form-control"
                                                       name="value" value="{{$data->value}}"
                                                       id="value" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="m-portlet__foot m-portlet__foot--fit">
                                    <div class="m-form__actions">
                                        <button type="submit" class="btn btn-success">تعديل</button>
                                        <a href="{{ route('admin.donations.index',$data->needy_id) }}" class="btn btn-secondary">إلغاء</a>
                                    </div>
                                </div>
                            </form>
                            <!--end::Form-->
                        </div>
                        <!--end::Portlet-->
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
